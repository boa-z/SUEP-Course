#ifndef __UART_H_
#define __UART_H_

#include "delay.h"
#include <stdio.h>
extern  volatile uint8 WriteFLAG;
extern  volatile uint8 ReadFLAG;
extern  volatile uint8 ClearFLAG;

extern void Uart1_Init(void);
extern void SendDataByUart1(uint8 dat);

#endif
