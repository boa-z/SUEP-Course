#ifndef __AT24C_H
#define __AT24C_H		
#include "delay.h"	

#define AT24C01		127
#define AT24C02		255
#define AT24C04		511
#define AT24C08		1023
#define AT24C16		2047
#define AT24C32		4095
#define AT24C64	  8191
#define AT24C128	16383
#define AT24C256	32767  
 
#define SLAW	0xA0               //I2C�ӻ�д��ַ
#define SLAR	0xA1               //I2C�ӻ�����ַ


#define E2PROM_TYPE  AT24C02
#define  AT24CXX_SIZE				  256			  // �궨��AT24C02������ 


uint8 AT24CXX_RcvOneByte(uint16 Addr);
void AT24CXX_SendOneByte(uint16 Addr,uint8 Data);              
void AT24CXX_SendLenByte(uint16 Addr,uint8 *Data,uint16 Len);
void AT24CXX_RcvLenByte(uint16 Addr,uint8 *Data,uint16 Len);
void AT24CXX_EraseOneByte(uint16 Addr);
void AT24CXX_EraseAll(void);


#endif 
