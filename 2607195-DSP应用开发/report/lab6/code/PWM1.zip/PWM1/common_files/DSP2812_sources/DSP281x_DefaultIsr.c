// ###########################################################################
//
//  FILE:	DSP281x_DefaultIsr.c
//
//  TITLE:	DSP281x Device Default Interrupt Service Routines.
//
// ###########################################################################
//
//   Ver | dd mmm yyyy | Who  | Description of changes
//  =====|=============|======|===============================================
//   1.00| 11 Sep 2003 | L.H. | Changes since previous version (v.58 Alpha)
//       |             |      | Search & Replace PieCtrl. with PieCtrlRegs.
//       |             |      | Added PIE Ack statements for XINT1 and XINT2 ISRs
//       |             |      | Changed the order to match the PIE vector table
//       |             |      | Changed USER0-USER11 to USER1-USER12
// ###########################################################################

#include "DSP281x_Device.h"   // DSP281x Headerfile Include File
#include "DSP281x_Examples.h" // DSP281x Examples Include File
#include "My_Main_Declaration.h"

// Note CPU-Timer1 ISR is reserved for TI use.
interrupt void INT13_ISR(void) // INT13 or CPU-Timer1
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// Note CPU-Timer2 ISR is reserved for TI use.
interrupt void INT14_ISR(void) // CPU-Timer2
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void DATALOG_ISR(void) // Datalogging interrupt
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void RTOSINT_ISR(void) // RTOS interrupt
{
  // Insert ISR Code here
  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void EMUINT_ISR(void) // Emulation interrupt
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void NMI_ISR(void) // Non-maskable interrupt
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void ILLEGAL_ISR(void) // Illegal operation TRAP
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("          ESTOP0");
  for (;;)
    ;
}

interrupt void USER1_ISR(void) // User Defined trap 1
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER2_ISR(void) // User Defined trap 2
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER3_ISR(void) // User Defined trap 3
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER4_ISR(void) // User Defined trap 4
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER5_ISR(void) // User Defined trap 5
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER6_ISR(void) // User Defined trap 6
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER7_ISR(void) // User Defined trap 7
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER8_ISR(void) // User Defined trap 8
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER9_ISR(void) // User Defined trap 9
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER10_ISR(void) // User Defined trap 10
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER11_ISR(void) // User Defined trap 11
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void USER12_ISR(void) // User Defined trap 12
{
  // Insert ISR Code here

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// -----------------------------------------------------------
// PIE Group 1 - MUXed into CPU INT1
// -----------------------------------------------------------

// INT1.1
interrupt void PDPINTA_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT1.2
interrupt void PDPINTB_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT1.3 - Reserved

// INT1.4
interrupt void XINT1_ISR(void)
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT1.5
interrupt void XINT2_ISR(void)
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT1.6
interrupt void ADCINT_ISR(void) // ADC
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT1.7
interrupt void TINT0_ISR(void) // CPU-Timer 0
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code

  CpuTimer0.InterruptCount++;
  if (CpuTimer0.InterruptCount == 1)
  {
    LED1_ON;
    LED4_OFF;
  }
  if (CpuTimer0.InterruptCount == 2)
  {
    LED1_OFF;
    LED2_ON;
  }
  if (CpuTimer0.InterruptCount == 3)
  {
    LED2_OFF;
    LED3_ON;
  }
  if (CpuTimer0.InterruptCount == 4)
  {
    LED3_OFF;
    LED4_ON;
    CpuTimer0.InterruptCount = 0;
  }

  CpuTimer0Regs.TCR.bit.TIF = 1;   // �����ʱ���жϱ�־λ
  PieCtrlRegs.PIEACK.bit.ACK1 = 1; // ��Ӧͬ�������ж�
  EINT;                            // ��ȫ���ж�
}

// INT1.8
interrupt void WAKEINT_ISR(void) // WD
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// -----------------------------------------------------------
// PIE Group 2 - MUXed into CPU INT2
// -----------------------------------------------------------

// INT2.1
interrupt void CMP1INT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.2
interrupt void CMP2INT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.3
interrupt void CMP3INT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.4
interrupt void T1PINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.5
interrupt void T1CINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.6
interrupt void T1UFINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.7
interrupt void T1OFINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT2.8 - Reserved

// -----------------------------------------------------------
// PIE Group 3 - MUXed into CPU INT3
// -----------------------------------------------------------

// INT 3.1
interrupt void T2PINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.2
interrupt void T2CINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.3
interrupt void T2UFINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.4
interrupt void T2OFINT_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.5
interrupt void CAPINT1_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.6
interrupt void CAPINT2_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.7
interrupt void CAPINT3_ISR(void) // EV-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT3.8 - Reserved

// -----------------------------------------------------------
// PIE Group 4 - MUXed into CPU INT4
// -----------------------------------------------------------

// INT 4.1
interrupt void CMP4INT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.2
interrupt void CMP5INT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.3
interrupt void CMP6INT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.4
interrupt void T3PINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.5
interrupt void T3CINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.6
interrupt void T3UFINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.7
interrupt void T3OFINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT4.8 -- Reserved

// -----------------------------------------------------------
// PIE Group 5 - MUXed into CPU INT5
// -----------------------------------------------------------

// INT 5.1
interrupt void T4PINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.2
interrupt void T4CINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.3
interrupt void T4UFINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.4
interrupt void T4OFINT_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.5
interrupt void CAPINT4_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.6
interrupt void CAPINT5_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.7
interrupt void CAPINT6_ISR(void) // EV-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP5;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT5.8 - Reserved

// -----------------------------------------------------------
// PIE Group 6 - MUXed into CPU INT6
// -----------------------------------------------------------

// INT6.1
interrupt void SPIRXINTA_ISR(void) // SPI-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT6.2
interrupt void SPITXINTA_ISR(void) // SPI-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT6.3 - Reserved
// INT6.4 - Reserved

// INT6.5
interrupt void MRINTA_ISR(void) // McBSP-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT6.6
interrupt void MXINTA_ISR(void) // McBSP-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT6.7 - Reserved
// INT6.8 - Reserved

// -----------------------------------------------------------
// PIE Group 7 - MUXed into CPU INT7
// -----------------------------------------------------------

// INT7.1 - Reserved
// INT7.2 - Reserved
// INT7.3 - Reserved
// INT7.4 - Reserved
// INT7.5 - Reserved
// INT7.6 - Reserved
// INT7.7 - Reserved
// INT7.8 - Reserved

// -----------------------------------------------------------
// PIE Group 8 - MUXed into CPU INT8
// -----------------------------------------------------------

// INT8.1 - Reserved
// INT8.2 - Reserved
// INT8.3 - Reserved
// INT8.4 - Reserved
// INT8.5 - Reserved
// INT8.6 - Reserved
// INT8.7 - Reserved
// INT8.8 - Reserved

// -----------------------------------------------------------
// PIE Group 9 - MUXed into CPU INT9
// -----------------------------------------------------------

// INT9.1
interrupt void SCIRXINTA_ISR(void) // SCI-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT9.2
interrupt void SCITXINTA_ISR(void) // SCI-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT9.3
interrupt void SCIRXINTB_ISR(void) // SCI-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT9.4
interrupt void SCITXINTB_ISR(void) // SCI-B
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT9.5
interrupt void ECAN0INTA_ISR(void) // eCAN-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// INT9.6
interrupt void ECAN1INTA_ISR(void) // eCAN-A
{
  // Insert ISR Code here

  // To receive more interrupts from this PIE group, acknowledge this interrupt
  // PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;

  // Next two lines for debug only to halt the processor here
  // Remove after inserting ISR Code
  asm("      ESTOP0");
  for (;;)
    ;
}

// -----------------------------------------------------------
// PIE Group 10 - MUXed into CPU INT10
// -----------------------------------------------------------

// INT10.1 - Reserved
// INT10.2 - Reserved
// INT10.3 - Reserved
// INT10.4 - Reserved
// INT10.5 - Reserved
// INT10.6 - Reserved
// INT10.7 - Reserved
// INT10.8 - Reserved

// -----------------------------------------------------------
// PIE Group 11 - MUXed into CPU INT11
// -----------------------------------------------------------

// INT11.1 - Reserved
// INT11.2 - Reserved
// INT11.3 - Reserved
// INT11.4 - Reserved
// INT11.5 - Reserved
// INT11.6 - Reserved
// INT11.7 - Reserved
// INT11.8 - Reserved

// -----------------------------------------------------------
// PIE Group 12 - MUXed into CPU INT12
// -----------------------------------------------------------

// INT12.1 - Reserved
// INT12.2 - Reserved
// INT12.3 - Reserved
// INT12.4 - Reserved
// INT12.5 - Reserved
// INT12.6 - Reserved
// INT12.7 - Reserved
// INT12.8 - Reserved

//---------------------------------------------------------------------------
// Catch All Default ISRs:
//

interrupt void EMPTY_ISR(void) // Empty ISR - only does a return.
{
}

interrupt void PIE_RESERVED(void) // Reserved space.  For test.
{
  asm("      ESTOP0");
  for (;;)
    ;
}

interrupt void rsvd_ISR(void) // For test
{
  asm("      ESTOP0");
  for (;;)
    ;
}

//===========================================================================
// No more.
//===========================================================================
