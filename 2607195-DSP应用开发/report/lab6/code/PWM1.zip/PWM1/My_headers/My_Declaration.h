/*
 * My_Declaration.h
 *
 *  Created on: 2016-2-26
 *      Author: Administrator
 */

#ifndef MY_DECLARATION_H_
#define MY_DECLARATION_H_

//===========================================================
#include"DSP281x_Device.h"
#include"DSP281x_GlobalPrototypes.h"
#include"Macro_definition.h"
//===========================================================
//===========================================================
extern void Init_Gpio(void);
extern void delay(int time_ms);
extern void quick_delay(int time_ms);
//===========================================================

#endif /* MY_DECLARATION_H_ */
