/*
 * Sub_Function.c
 *
 *  Created on: 2016-2-26
 *      Author: Administrator
 */
#include"My_Declaration.h"

//=========================================================
//��ʱ����ms
//=========================================================
void delay(int time_ms)
{
	unsigned long a,b,c;
	for(a=0;a<time_ms;a++)
	{
		for(b=0;b<1000;b++)
		{
			for(c=0;c<150;c++)
			{

			}
		}
	}
}

void quick_delay(int time_ms)
{
    unsigned long a,c;
    for(a=0;a<time_ms;a++)
    {

            for(c=0;c<150;c++)
            {

            }

    }
}
