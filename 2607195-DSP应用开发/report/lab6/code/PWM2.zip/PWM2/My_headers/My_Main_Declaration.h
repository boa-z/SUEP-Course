/*
 * My_Main_Declaration.h
 *
 *  Created on: 2016-2-26
 *      Author: Administrator
 */

#ifndef MY_MAIN_DECLARATION_H_
#define MY_MAIN_DECLARATION_H_
//===========================================================
#include"DSP281x_Device.h"
#include"DSP281x_GlobalPrototypes.h"
#include"Macro_definition.h"

//===========================================================
//===========================================================
void Init_Gpio(void);
void delay(int time_ms);
void quick_delay(int time_ms);
//===========================================================


#endif /* MY_MAIN_DECLARATION_H_ */
